#!/bin/bash
echo "Running AfterInstall script..."

sudo chown -R ubuntu:ubuntu /home/ubuntu/MERNAPPBE

# Install backend dependencies
cd /home/ubuntu/MERNAPPBE
npm install

echo "AfterInstall script completed."
