#!/bin/bash
echo "Running ApplicationStart script..."

# Ensure the correct PATH for Node.js and npm
export PATH=$PATH:/home/ubuntu/.nvm/versions/node/v22.12.0/bin  # Adjust this path as needed
echo "Using Node.js from $(which node)"
echo "Using npm from $(which npm)"

# Stop any running PM2 processes
echo "Stopping PM2 processes..."
pm2 stop all || echo "No PM2 processes were running."

# Backend: Start server
echo "Starting backend server..."
cd /home/ubuntu/MERNAPPBE || { echo "Failed to cd into /home/ubuntu/MERNAPPBE"; exit 1; }

# Ensure backend directory permissions are correct
sudo chown -R ubuntu:ubuntu /home/ubuntu/MERNAPPBE
sudo chmod -R u+rw /home/ubuntu/MERNAPPBE

pm2 start index.js --name my-backend || { echo "Failed to start backend server with PM2"; exit 1; }

npm install || { echo "npm install failed"; exit 1; }

# Save PM2 process list
echo "Saving PM2 process list..."
pm2 save || { echo "Failed to save PM2 process list"; exit 1; }

# Restart Nginx to apply new changes
echo "Restarting Nginx..."
sudo systemctl restart nginx.service || { echo "Failed to restart nginx"; exit 1; }

echo "ApplicationStart script completed successfully."