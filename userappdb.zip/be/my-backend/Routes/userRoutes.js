const express = require("express");
const db = require("../config/db");
const router = express.Router();

router.post("/register", (req, res) => {
  const { username, email, password } = req.body;
	console.log(req.body)
  if (!username || !email || !password) {
    return res.status(400).json({ error: "All fields are required!" });
  }

  const query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
  db.query(query, [username, email, password], (err) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: "Failed to register user!" });
    }
    res.status(201).json({ message: "User registered successfully!" });
  });
});

module.exports = router;
