import React from "react";
import Register from "./components/Register";

function App() {
  return (
    <div>
      <Register />
    </div>
  );
}

export default App;
