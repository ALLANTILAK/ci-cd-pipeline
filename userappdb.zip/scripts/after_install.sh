#!/bin/bash
echo "Running AfterInstall script..."

# Install frontend dependencies
cd /var/www/html/fe
npm install

# Install backend dependencies
cd /var/www/html/be
npm install

echo "AfterInstall script completed."
