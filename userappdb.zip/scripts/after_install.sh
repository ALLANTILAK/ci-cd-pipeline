#!/bin/bash
echo "Running AfterInstall script..."

sudo chown -R ubuntu:ubuntu /home/ubuntu/userappdb

# Install frontend dependencies
cd /home/ubuntu/userappdb/my-frontend
sudo npm install

# Install backend dependencies
cd /home/ubuntu/userappdb/my-backend
sudo npm install

echo "AfterInstall script completed."
