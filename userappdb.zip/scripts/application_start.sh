#!/bin/bash

echo "Starting ApplicationStart script..."

# Ensure npm is available and log its path
echo "Using npm from $(which npm)"
if ! command -v npm &> /dev/null; then
  echo "Error: npm not found. Ensure Node.js and npm are installed and available in the PATH."
  exit 1
fi

# Stop any running PM2 processes
echo "Stopping PM2 processes..."
pm2 stop all || echo "No PM2 processes were running."

# Backend: Start server
echo "Starting backend server..."
cd /home/ubuntu/userappdb/my-backend || { echo "Error: Failed to cd into /home/ubuntu/userappdb/my-backend"; exit 1; }

# Ensure backend directory permissions are correct
echo "Ensuring correct permissions for backend directory..."
sudo chown -R ubuntu:ubuntu /home/ubuntu/userappdb/my-backend
sudo chmod -R u+rw /home/ubuntu/userappdb/my-backend

# Start the backend application
pm2 start app.js --name my-backend || { echo "Error: Failed to start backend server with PM2"; exit 1; }

# Frontend: Clean, install dependencies, and build
echo "Building frontend..."
cd /home/ubuntu/userappdb/my-frontend || { echo "Error: Failed to cd into /home/ubuntu/userappdb/my-frontend"; exit 1; }

# Ensure frontend directory permissions are correct
echo "Ensuring correct permissions for frontend directory..."
sudo chown -R ubuntu:ubuntu /home/ubuntu/userappdb/my-frontend
sudo chmod -R u+rw /home/ubuntu/userappdb/my-frontend

# Clean dependencies and reinstall
echo "Cleaning and reinstalling npm dependencies..."
rm -rf node_modules package-lock.json || { echo "Error: Failed to remove node_modules or package-lock.json"; exit 1; }
npm install || { echo "Error: npm install failed"; exit 1; }

# Build the frontend application
echo "Building the frontend application..."
npm run build || { echo "Error: npm run build failed"; exit 1; }

# Save PM2 process list for restart
echo "Saving PM2 process list..."
pm2 save || { echo "Error: Failed to save PM2 process list"; exit 1; }

# Restart Nginx to apply new changes
echo "Restarting Nginx..."
sudo systemctl restart nginx.service || { echo "Error: Failed to restart Nginx"; exit 1; }

echo "ApplicationStart script completed successfully."