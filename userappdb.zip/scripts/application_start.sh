#!/bin/bash
echo "Running ApplicationStart script..."

# Stop any running PM2 processes
pm2 stop all || true

# Start backend server
cd /var/www/html/be
pm2 start app.js --name my-backend

# Build and serve frontend
cd /var/www/html/fe
npm run build

# Save PM2 process list
pm2 save

# Restart Nginx
sudo systemctl restart nginx.service

echo "ApplicationStart script completed."
