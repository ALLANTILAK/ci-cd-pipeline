#!/bin/bash
echo "Running ApplicationStart script..."

# Ensure the correct PATH for Node.js and npm
export PATH=$PATH:/home/ubuntu/.nvm/versions/node/v18.20.5/bin  # Adjust this path as needed
echo "Using Node.js from $(which node)"
echo "Using npm from $(which npm)"

# Stop any running PM2 processes
echo "Stopping PM2 processes..."
pm2 stop all || echo "No PM2 processes were running."

# Backend: Start server
echo "Starting backend server..."
cd /home/ubuntu/userappdb/my-backend || { echo "Failed to cd into /home/ubuntu/userappdb/my-backend"; exit 1; }

# Ensure backend directory permissions are correct
sudo chown -R ubuntu:ubuntu /home/ubuntu/userappdb/my-backend
sudo chmod -R u+rw /home/ubuntu/userappdb/my-backend

pm2 start app.js --name my-backend || { echo "Failed to start backend server with PM2"; exit 1; }

# Frontend: Build and serve
echo "Building frontend..."
cd /home/ubuntu/userappdb/my-frontend || { echo "Failed to cd into /home/ubuntu/userappdb/my-frontend"; exit 1; }

# Ensure frontend directory permissions are correct
sudo chown -R ubuntu:ubuntu /home/ubuntu/userappdb/my-frontend
sudo chmod -R u+rw /home/ubuntu/userappdb/my-frontend

npm install || { echo "npm install failed"; exit 1; }
npm run build || { echo "npm run build failed"; exit 1; }

# Save PM2 process list
echo "Saving PM2 process list..."
pm2 save || { echo "Failed to save PM2 process list"; exit 1; }

# Restart Nginx to apply new changes
echo "Restarting Nginx..."
sudo systemctl restart nginx.service || { echo "Failed to restart nginx"; exit 1; }

echo "ApplicationStart script completed successfully."