#!/bin/bash

# Use the CodeDeploy environment variable to get the dynamic deployment directory
DEPLOYMENT_ROOT="$CODEDEPLOY_DIR"

# Check if the before_install.sh exists and is executable, then set permissions
BEFORE_INSTALL_SCRIPT="$DEPLOYMENT_ROOT/scripts/before_install.sh"

# If the script exists, make it executable
if [ -f "$BEFORE_INSTALL_SCRIPT" ]; then
  chmod +x "$BEFORE_INSTALL_SCRIPT"
  echo "$BEFORE_INSTALL_SCRIPT is now executable."
else
  echo "before_install.sh script not found at $BEFORE_INSTALL_SCRIPT"
  exit 1
fi

# Set permissions for all other files in the deployment folder
echo "Setting permissions for other files in the deployment..."
chmod -R 755 "$DEPLOYMENT_ROOT"

# Run your additional setup steps (e.g., cleaning up directories)
echo "Running BeforeInstall phase..."

# Clean up existing directories and recreate them
sudo rm -rf /var/www/html/fe/my-frontend
sudo rm -rf /var/www/html/be/my-backend
sudo mkdir -p /var/www/html/fe/my-frontend
sudo mkdir -p /var/www/html/be/my-backend

echo "Directories cleaned and recreated."