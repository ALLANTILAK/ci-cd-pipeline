#!/bin/bash
echo "Running BeforeInstall script..."

# Update and install dependencies
sudo apt update -y
sudo apt install -y nodejs npm

# Remove old deployment files
rm -rf /var/www/html/fe
rm -rf /var/www/html/be

echo "BeforeInstall script completed."
