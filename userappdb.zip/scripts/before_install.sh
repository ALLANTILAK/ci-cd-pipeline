#!/bin/bash

# Define the working directory
DIR="/var/www/html"

# Check if the working directory exists, if not, create it
if [ -d "$DIR" ]; then
  echo "${DIR} exists"
else
  echo "Creating ${DIR} directory"
  mkdir -p ${DIR}
fi

# Attempt to resolve DEPLOYMENT_ID dynamically
if [ -z "$DEPLOYMENT_ID" ]; then
  echo "DEPLOYMENT_ID is not set. Attempting fallback..."
  DEPLOYMENT_DIR=$(find /opt/codedeploy-agent/deployment-root -type d -name 'deployment-archive' | head -n 1)
  if [ -z "$DEPLOYMENT_DIR" ]; then
    echo "Failed to locate deployment directory. Exiting."
    exit 1
  fi
else
  DEPLOYMENT_DIR="/opt/codedeploy-agent/deployment-root/$DEPLOYMENT_ID/deployment-archive"
fi

# Verify if the deployment directory exists
if [ ! -d "$DEPLOYMENT_DIR" ]; then
  echo "Deployment directory ${DEPLOYMENT_DIR} does not exist. Exiting."
  exit 1
fi

# Define the target directory
TARGET_DIR="/var/www/html"

# Copy files from the deployment directory to the target directory
echo "Copying files from ${DEPLOYMENT_DIR} to ${TARGET_DIR}"
cp -r "${DEPLOYMENT_DIR}"/* "${TARGET_DIR}/"

# Set ownership to ubuntu user
echo "Setting ownership for ${TARGET_DIR}"
sudo chown -R ubuntu:ubuntu ${TARGET_DIR}

echo "Files successfully copied and permissions set."
