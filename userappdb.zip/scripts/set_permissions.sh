#!/bin/bash

# Set executable permissions for the scripts
chmod +x /opt/codedeploy-agent/deployment-root/deployment-archive/scripts/*.sh

echo "Permissions set for scripts"