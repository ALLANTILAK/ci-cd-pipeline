#!/bin/bash

#give permission for everything in the userappdb directory
sudo chmod -R 777 /home/ubuntu/userappdb

# Navigate to backend directory
cd /home/ubuntu/var/www/html/fe/my-frontend

#install node modules
sudo npm install

#build
sudo npm run build

# Navigate to backend directory
cd /home/ubuntu/var/www/html/be/my-backend

#install node modules
npm install

# Restart backend using PM2
echo "Stopping existing backend process..."
pm2 delete my-backend || true
echo "Starting backend server..."
pm2 start app.js --name "my-backend"

# Ensure PM2 processes are saved
pm2 save

# Restart Nginx
echo "Restarting Nginx..."
sudo systemctl restart nginx

echo "Backend server and Nginx restarted successfully!"
