#!/bin/bash

# Navigate to backend directory
cd /var/www/html/be/my-backend

# Restart backend using PM2
echo "Stopping existing backend process..."
pm2 delete my-backend || true
echo "Starting backend server..."
pm2 start app.js --name "my-backend"

# Ensure PM2 processes are saved
pm2 save

# Restart Nginx
echo "Restarting Nginx..."
sudo systemctl restart nginx

echo "Backend server and Nginx restarted successfully!"