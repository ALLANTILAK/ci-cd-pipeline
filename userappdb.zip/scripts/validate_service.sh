#!/bin/bash

# Check if PM2 is running
if ! pm2 list | grep -q "my-backend"; then
  echo "PM2 is not running the backend application!"
  exit 1
fi

# Check if Nginx is running
if ! systemctl status nginx | grep -q "active (running)"; then
  echo "Nginx is not running!"
  exit 1
fi

echo "Validation successful: Backend and Nginx are running!"