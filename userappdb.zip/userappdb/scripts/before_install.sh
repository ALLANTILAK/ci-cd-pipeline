#!/bin/bash
echo "Running BeforeInstall phase..."
# Example tasks:
sudo rm -rf /var/www/html/fe/my-frontend
sudo rm -rf /var/www/html/be/my-backend
sudo mkdir -p /var/www/html/fe/my-frontend
sudo mkdir -p /var/www/html/be/my-backend
echo "Directories cleaned and recreated."